package ptut.metier;

import java.util.List;

/**
 *
 * @author Florian Hauwelle
 */
public class Produit {
    
    private String nomProduit;
    private String description;
    private float prix;
    private int stock;
    private int seuil_stock_alerte;
    private static int cpt = 1;
    private final int idProduit;
    private static List<Produit> listeDesProduits;
    private Categorie cat;
    private SousCategorie ss_cat;
    
    public Produit(){
        idProduit = -1;
    }
    
     public Produit(String nom, float prix, int stock){
        
        idProduit = cpt++;
        this.nomProduit = nom;
        this.prix = prix;
        this.stock = stock;
        //listeDesProduits.add(this);
    }
    
    public Produit(String nom, float prix, int stock, int seuil_stock_alerte){
        
        idProduit = cpt++;
        this.nomProduit = nom;
        this.prix = prix;
        this.stock = stock;
        this.seuil_stock_alerte = seuil_stock_alerte;
        //listeDesProduits.add(this);
    }
    
    public Produit(String nom, float prix, int stock, int seuil_stock_alerte, String description){
        
        idProduit = cpt++;
        this.nomProduit = nom;
        this.prix = prix;
        this.stock = stock;
        this.seuil_stock_alerte = seuil_stock_alerte;   
        this.description = description;
        //listeDesProduits.add(this);
    }
    
    /*public static List<Produit> getLesProduits(){
        return listeDesProduits;
    }*/
 

    public int getIdProduit(){ return idProduit;}
    
    public String getNom() {return nomProduit;}

    public void setNom(String nom) {this.nomProduit = nom;}

    public String getDescription() {return description;}

    public void setDescription(String description) {this.description = description;}

    public double getPrix() {return prix;}

    public void setPrix(float prix) {this.prix = prix;}

    public int getStock() {return stock;}

    public void setStock(int stock) {this.stock = stock;}

    public int getSeuil_stock_alerte() {return seuil_stock_alerte;}

    public void setSeuil_stock_alerte(int seuil_stock_alerte) {this.seuil_stock_alerte = seuil_stock_alerte;}

    public Categorie getCat() {return cat;}

    public void setCat(Categorie cat) {this.cat = cat;}
    
    public SousCategorie getSs_cat() {return ss_cat;}
    
    public static String[] enumCatToStringArray(){
        String[] results = new String[Categorie.values().length];
        int count = 0;
        for(Categorie each : Categorie.values()){
            results[count] = each.toString();
            count++;
        }
    return results;
    }
    
}
