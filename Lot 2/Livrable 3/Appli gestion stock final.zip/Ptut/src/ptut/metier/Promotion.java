package ptut.metier;

/**
 *
 * @author Florian Hauwelle
 */
public class Promotion {
    
}
