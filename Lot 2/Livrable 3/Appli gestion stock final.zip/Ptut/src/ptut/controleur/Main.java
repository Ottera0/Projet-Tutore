/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ptut.controleur;

import java.util.List;
import ptut.vue.FenConnexion;
import ptut.metier.Produit;

/**
 *
 * @author Florian Hauwelle
 */
public class Main {
    
    public static void main (String[] args){ 
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FenConnexion().setVisible(true);
            }
        });
    }
}   
