/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ptut.metier;

/**
 *
 * @author fhauw
 */
public enum SousCategorie {
  Arbres_fruitiers,Conifères,Fleurs_comestibles,Fleurs_non_comestibles,Cactus,Succulentes;
}
