
package ptut.metier;

/**
 *
 * @author Florian Hauwelle
 */

public enum Categorie {
    Arbres, Fleurs, Plantes_grasses ;
}
