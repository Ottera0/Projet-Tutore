/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ptut.metier;

/**
 *
 * @author dQ
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ptut.vue.FenAccueil;

public class DAOProduit {
    
    Connection connection;
    
    public DAOProduit(){ // test à la connexion à la BD
        String url ="jdbc:mysql://localhost:3306/ptut";
        
        try{
            connection = DriverManager.getConnection(url, "root", "");
        }catch (Exception exp){
            System.out.println(exp);
        }
    }

    public List<Produit> getLesProduits() {
        List<Produit> liste = new ArrayList<Produit>();
        String sql="select * from produit"; // requête SQL sur la la table Produit
        
        try{
            Produit plante;
            PreparedStatement pst = connection.prepareStatement(sql); // exécution de la requête
            ResultSet rs = pst.executeQuery(); // stock le résultat dans ResultSet
            while(rs.next()){ // parcours du ResultSet pour remplir la liste
                plante = new Produit(rs.getString("nomProduit"),rs.getFloat("prix"), rs.getInt("stock"));
                liste.add(plante);
            }
        }catch(Exception exp){
            System.out.println(exp);
        }
        return liste;
    }
    
    /*public void createProduit(Produit p){
        String sql="insert into Produit(nomProduit, prix, stock, seuilStockAlerte, description) values(?,?,?,?,?)"; // requête SQL
        try{
            PreparedStatement pst = connection.prepareStatement(sql); // exécution de la requête
            pst.setString(1, p.getNom());
            pst.setDouble(2, p.getPrix());
            pst.setInt(3, p.getStock());
            pst.setInt(4,p.getSeuil_stock_alerte());
            pst.setString(5, p.getDescription());
            boolean b = pst.execute();
        }catch(Exception exp){
            System.out.println(exp);
        }
    }*/
    
    public void deleteProduit(int idProduit){
        String sql="delete from Produit where idProduit = ?"; // requête sql
        try{
            PreparedStatement pst = connection.prepareStatement(sql); // exécution de la requête
            pst.setInt(1, idProduit);
            pst.execute();
        }catch(Exception exp){
            System.out.println(exp);
        }
    }
    
    public Produit getProduitById(int idProduit){
        String sql = "select * from Produit where idProduit = ?";
        try{
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, idProduit);
            ResultSet res = pst.executeQuery();
            if(res.next()){
                // créer le produit et le retourner
                Produit p = new Produit(res.getString("nomProduit"), res.getFloat("prix"), res.getInt("stock"));
                return p;
            }
        }catch(Exception exp){
            System.out.println(exp);
        }
        return null;
    }
    
   /* public void updateProduit(Produit p){
        String sql = "update produit set nomproduit = ?, prix = ? where idProduit = ?";
        try{
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1,p.getNom());
            pst.setDouble(2, p.getPrix());
            pst.setInt(3, p.getIdProduit());
            pst.execute();
        }catch(Exception exp){
            System.out.println(exp);
        }
    }*/
}
    
        
    
