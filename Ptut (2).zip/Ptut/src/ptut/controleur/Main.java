/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ptut.controleur;

import java.util.List;
import ptut.metier.DAOProduit;
import ptut.vue.FenConnexion;
import ptut.metier.Produit;

/**
 *
 * @author dQ
 */
public class Main {
    
    public static void main (String[] args){ 
    
       /*DAOProduit pdao = new DAOProduit();
        
       // Produit jonq = new Produit("Jonquille", (float) 6.30, 99);
       /* Produit test = pdao.getProduitById(8);
        if(test != null){
            System.out.println("**********");
            System.out.println(test.getIdProduit()+" "+ test.getNom()+" "+ test.getPrix()+" "+ test.getStock());
        }
        System.out.println("Liste.........................");
        pdao.deleteProduit(6);*/
       
       /* Produit pr = pdao.getProduitById(4);
        if(pr != null){ // si le produit existe on l'update
            pr.setNom("Jonquille");
            pr.setPrix((float)3.50);
            pdao.updateProduit(pr);
        }
       
        List<Produit> liste = pdao.getLesProduits();
        for(Produit p:liste){
           System.out.println(p.getNom()+ ""+p.getPrix()+""+p.getStock());
        }

        /*java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FenConnexion().setVisible(true);
            }
        });*/
    }
}
    
